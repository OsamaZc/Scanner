import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class File2TokenList {
    public static List<String> convertFileToTokenList(File file) {
        List<String> tokens = new ArrayList<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                tokens.addAll(Arrays.stream(line.trim().split(" ")).toList());
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found.");
        } catch (IOException e) {
            System.err.println("Error reading the file.");
        }
        return tokens;
    }
}