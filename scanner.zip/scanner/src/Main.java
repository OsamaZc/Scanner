import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter input (type 'END' on a new line to finish):");
        StringBuilder userInput = new StringBuilder();
        String line;
        while (!(line = scanner.nextLine()).equals("END")) {
            userInput.append(line).append("\n");
        }
        scanner.close();

        // Combine adjacent whitespaces into a single whitespace but leave newlines
        String normalizedInput = userInput.toString().replaceAll("[ \t\f\r]+", " ");


        // Updated regex to handle comments, string literals, and other tokens
        List<String> tokens = Arrays.stream(
                        Pattern.compile("//.*|/\\*.*?\\*/|\"(\\\\.|[^\"])*\"|\\w+|\\S|<<|>>|==|!=|<=|>=")
                                .matcher(normalizedInput)
                                .results()
                                .map(mr -> mr.group())
                                .toArray(String[]::new))
                .collect(Collectors.toList());


        for (String token : tokens) {
            Optional<String> tokenType = TokenMapper.checkToken(token);
            System.out.println("Token: " + token + ", Type: " + tokenType.orElse("Unknown"));
        }
    }
}